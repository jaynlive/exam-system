require 'test_helper'

class ExamsHelperTest < ActionView::TestCase
end
