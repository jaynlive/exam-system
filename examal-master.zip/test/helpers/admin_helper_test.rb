require 'test_helper'

class AdminHelperTest < ActionView::TestCase
end
