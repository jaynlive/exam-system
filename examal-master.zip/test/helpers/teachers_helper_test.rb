require 'test_helper'

class TeachersHelperTest < ActionView::TestCase
end
