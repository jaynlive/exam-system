require 'test_helper'

class PanelHelperTest < ActionView::TestCase
end
