require 'test_helper'

class ATest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
