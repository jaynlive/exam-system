require 'test_helper'

class PanelControllerTest < ActionController::TestCase
  # test "should get index" do
  #   get :index
  #   assert_response :success
  # end

  # test "should get taken" do
  #   get :taken
  #   assert_response :success
  # end

  # test "should get untaken" do
  #   get :untaken
  #   assert_response :success
  # end

  # test "should get info" do
  #   get :info
  #   assert_response :success
  # end

end
