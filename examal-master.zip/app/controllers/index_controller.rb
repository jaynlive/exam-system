class IndexController < ApplicationController
  def index
  	unless session[:user_id].nil?
		  redirect_to panel_index_url
    end
  	@username=""
  	@user = User.new()
  end

  def new
  	userinfo=login_param
  	@username=userinfo[:username]
  	respond_to do |format|
      if user=User.auth(userinfo[:username],userinfo[:password])
      	session[:user_id]=user.id
		    session[:user_username]=user.username
        format.html { redirect_to panel_index_url}
      else
        format.html { redirect_to index_url,:notice => "不正确的用户名/密码" }
      end
    end
  end

  def create
  	@user = User.new(reg_param)
  	respond_to do |format|
      if @user.save
        format.html { redirect_to index_url, notice: "成功创建账户!用户:#{@user.username},姓名:#{@user.name}. "}
      else
        format.html { render :create }
      end
    end
  end
  def destroy
  	session[:user_id]=nil
    redirect_to index_url
  end

  private

  def login_param
  	params.permit(:username,:password)
  end
  def reg_param
  	params.permit(:username, :name, :password, :age, :sex, :school, :college, :profession, :work)
  end
end
